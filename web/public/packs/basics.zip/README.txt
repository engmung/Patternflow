Patternflow - Basics pattern pack

33 patterns, in running order.

To install: open your board's Patterns page and drop this .zip on the
upload area. Your browser unpacks it and the patterns appear in the
list - no reflash, and nothing to unzip yourself.

Published by: Patternflow
Author:  Seunghun LEE
Licence: CC-BY-SA-4.0
Per-pattern attribution stays in each .json beside its .pfm.

https://patternflow.work
